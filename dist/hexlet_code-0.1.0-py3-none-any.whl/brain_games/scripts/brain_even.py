from brain_games.game_starter import starter
from brain_games.games.brain_even import get_game_even


def main():
    starter(get_game_even)


if __name__ == '__main__':
    main()
