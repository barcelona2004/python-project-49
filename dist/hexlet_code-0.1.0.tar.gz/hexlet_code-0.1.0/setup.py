# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:hello',
                     'brain-gcd = brain_games.scritps.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'A game for your brain',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/barcelona2004/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/barcelona2004/python-project-49/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/b25d8a26248f76ede1c4/maintainability)](https://codeclimate.com/github/barcelona2004/python-project-49/maintainability)\n\nPoetry version - 6.0.0\nPython version - 3.8.10 \nMakefile commands:\n\tinstall, build, publish, package-install - you need to install package\n\tbrain-name - run game\n\tlint - show linter mistakes \t\t\n\n[![asciicast](https://asciinema.org/a/Bf6yaRclezcZQfStvLClUlRCr.svg)](https://asciinema.org/a/Bf6yaRclezcZQfStvLClUlRCr) - how to install package\n[![asciicast](https://asciinema.org/a/9XaQsl9Fx861dqCVWeJu2VRa7.svg)](https://asciinema.org/a/9XaQsl9Fx861dqCVWeJu2VRa7) - brain-even\n[![asciicast](https://asciinema.org/a/JgXItVb02uSiq2KnSAtT3WrPZ.svg)](https://asciinema.org/a/JgXItVb02uSiq2KnSAtT3WrPZ) - brain-calc\n[![asciicast](https://asciinema.org/a/XLEZJHAm84PRNz0va6Y23YJT5.svg)](https://asciinema.org/a/XLEZJHAm84PRNz0va6Y23YJT5) - brain-gcd\n[![asciicast](https://asciinema.org/a/AmtWJKL9f4Yrg1MKr1BjFw5TG.svg)](https://asciinema.org/a/AmtWJKL9f4Yrg1MKr1BjFw5TG) - brain-progression\n[![asciicast](https://asciinema.org/a/U9yewbTyVv90yceabPZv7KF4d.svg)](https://asciinema.org/a/U9yewbTyVv90yceabPZv7KF4d) - brain-prime\n',
    'author': 'Gordt Maxim',
    'author_email': 'barcelona200418@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/barcelona2004/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.10,<4.0.0',
}


setup(**setup_kwargs)
