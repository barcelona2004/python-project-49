from brain_games.game_starter import start_game
from brain_games.games import brain_even


def main():
    start_game(brain_even)


if __name__ == '__main__':
    main()
