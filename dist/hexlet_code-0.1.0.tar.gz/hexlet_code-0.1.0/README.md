### Hexlet tests and linter status:
[![Actions Status](https://github.com/barcelona2004/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/barcelona2004/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/b25d8a26248f76ede1c4/maintainability)](https://codeclimate.com/github/barcelona2004/python-project-49/maintainability)

Poetry version - 6.0.0
Python version - 3.8.10 
Makefile commands:
	install, build, publish, package-install - you need to install package
	brain-name - run game
	lint - show linter mistakes 		

[![asciicast](https://asciinema.org/a/Bf6yaRclezcZQfStvLClUlRCr.svg)](https://asciinema.org/a/Bf6yaRclezcZQfStvLClUlRCr) - how to install package
[![asciicast](https://asciinema.org/a/9XaQsl9Fx861dqCVWeJu2VRa7.svg)](https://asciinema.org/a/9XaQsl9Fx861dqCVWeJu2VRa7) - brain-even
[![asciicast](https://asciinema.org/a/JgXItVb02uSiq2KnSAtT3WrPZ.svg)](https://asciinema.org/a/JgXItVb02uSiq2KnSAtT3WrPZ) - brain-calc
[![asciicast](https://asciinema.org/a/XLEZJHAm84PRNz0va6Y23YJT5.svg)](https://asciinema.org/a/XLEZJHAm84PRNz0va6Y23YJT5) - brain-gcd
[![asciicast](https://asciinema.org/a/AmtWJKL9f4Yrg1MKr1BjFw5TG.svg)](https://asciinema.org/a/AmtWJKL9f4Yrg1MKr1BjFw5TG) - brain-progression
[![asciicast](https://asciinema.org/a/U9yewbTyVv90yceabPZv7KF4d.svg)](https://asciinema.org/a/U9yewbTyVv90yceabPZv7KF4d) - brain-prime
