### Hexlet tests and linter status:
[![Actions Status](https://github.com/barcelona2004/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/barcelona2004/python-project-49/actions)
<a href="https://codeclimate.com/github/barcelona2004/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/9bc31d1884d47ac32857/maintainability" /></a>
https://asciinema.org/a/fojaWaqvqJ1y3AB508BoL1Tjy - package installation
https://asciinema.org/a/9XaQsl9Fx861dqCVWeJu2VRa7 - brain-even
https://asciinema.org/a/JgXItVb02uSiq2KnSAtT3WrPZ - brain-calc
https://asciinema.org/a/XLEZJHAm84PRNz0va6Y23YJT5 - brain-gcd
https://asciinema.org/a/AmtWJKL9f4Yrg1MKr1BjFw5TG - brain-progression
https://asciinema.org/a/U9yewbTyVv90yceabPZv7KF4d - brain-prime
